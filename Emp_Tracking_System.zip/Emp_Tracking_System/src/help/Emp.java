package help;
import java.math.*;

public class Emp {  
private int id;private String mobile;  
private String name,pass,email,dep,addr;

	public int getId() {  return id;  }  
	public void setId(int id) { this.id = id;  }
	
	
	public String getName() {return name;}
	public void setName(String name) {this.name=name;}

	public String getPass() {return pass;}
	public void setPass(String pass) {this.pass=pass;}

											 
	public String getEmail() {return email;}
	public void setEmail(String email) {this.email=email;}	
 
  
	public String getDep() {return dep;}
	public void setDep(String dep) {this.dep=dep;} 

	public String getAddr() {return addr;}
	public void setAddr(String addr) {this.addr=addr;}

	public String getMobile() {return mobile;}
	public void setMobile(String mobile) {this.mobile=mobile;}

}  
