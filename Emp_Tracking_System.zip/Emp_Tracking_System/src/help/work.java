package help;

public class work {
	
	private String name,pname,role,perf;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	private int id;
	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getPerf() {
		return perf;
	}


	public void setPerf(String perf) {
		this.perf = perf;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}
	

}
